import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;
import java.util.logging.*;

/**
 * 社員情報を管理するクラス
 */
public class EmployeeManager {
    private static final String DATA_FOLDER = "NameInfoApp/Data"; // データ保存先のフォルダ
    private static final String LOG_FOLDER = "NameInfoApp/Log"; // ログ保存先のフォルダ
    private static final String CSV_FILE = DATA_FOLDER + "/NameInfo.csv"; // CSVファイルのパス
    private List<Employee> employees; // 社員情報のリスト
    private Logger logger; // ログ機能

    /**
     * コンストラクタ
     */
    public EmployeeManager() {
        employees = new ArrayList<>();
        logger = Logger.getLogger("EmployeeLogger");
        setupLogger(); // ロガーの設定
        loadEmployees(); // CSVから社員データを読み込み
    }

    /**
     * ログを設定する
     */
    private void setupLogger() {
        try {
            // ログフォルダを作成
            Files.createDirectories(Paths.get(LOG_FOLDER));
            String logFile = LOG_FOLDER + "/NameInfoApp-" + LocalDate.now() + ".log";
            FileHandler fh = new FileHandler(logFile, true);

            // ログのフォーマットを設定
            // ログの利用方法をよく調べてチームの仕様に合わせて変更・対応してください
            System.setProperty("java.util.logging.SimpleFormatter.format", "%1$tF %1$tT %4$s %2$s %5$s%6$s%n");
            fh.setFormatter(new SimpleFormatter());

            logger.addHandler(fh);
        } catch (IOException e) {
            // スタックトレースを文字列で取得してログに出力する
            printLogStackTrace(e, "ログ設定で例外が発生しました");
        }
    }

    /**
     * 社員情報をCSVファイルから読み込む.
     */
    private void loadEmployees() {
        try {
            // データフォルダを作成
            Files.createDirectories(Paths.get(DATA_FOLDER));
            File file = new File(CSV_FILE);
            if (!file.exists()) {
                file.createNewFile(); // ファイルがない場合は新規作成
            } else {
                // CSVファイルから社員情報を読み込む
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String[] data = line.split(",");
                        String id = data[0];
                        String name = data[1];

                        LocalDate birthDate = LocalDate.parse(data[2]);
                        LocalDate joinDate = LocalDate.parse(data[3]);
                        List<String> languages = Arrays.asList(data[4].split("\\|"));
                        String career = data[5];
                        String trainingHistory = data[6];
                        double technicalSkill = Double.parseDouble(data[7]);
                        double learningAttitude = Double.parseDouble(data[8]);
                        double communicationSkill = Double.parseDouble(data[9]);
                        double leadership = Double.parseDouble(data[10]);
                        String remarks = data[11];
                        employees.add(
                                new Employee(
                                        id,
                                        name,
                                        birthDate,
                                        joinDate,
                                        languages,
                                        career,
                                        trainingHistory,
                                        technicalSkill,
                                        learningAttitude,
                                        communicationSkill,
                                        leadership,
                                        remarks));
                    }
                }
            }
        } catch (IOException e) {
            printLogStackTrace(e, "CSVから社員情報の読み込む際に例外が発生しました");
        }
    }

    /**
     * ログにスタックトレースを出力する
     * 
     * @param e           スタックトレースを持っている例外クラス
     * @param errorString ログに出力するエラー文言
     */
    private void printLogStackTrace(Exception e, String errorString) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        logger.severe(String.format("%s¥n%s", errorString, sw.toString()));
    }

    /**
     * 社員情報を追加する
     * 
     * @param employee 社員情報
     */
    public void addEmployee(Employee employee) {
        employees.add(employee); // 社員情報の追加
        saveEmployees(); // CSVに保存
        logger.info("社員情報を追加: " + employee); // ログ出力
    }

    /**
     * 社員情報を削除する
     * 
     * @param employee 対象の社員情報
     */
    public void removeEmployee(Employee employee) {
        employees.remove(employee); // 社員情報の削除
        saveEmployees(); // CSVに保存
        logger.info("社員情報を削除: " + employee); // ログ出力
    }

    /**
     * CSVに社員情報を保存する
     */
    public void saveEmployees() {
        // CSVファイルに社員情報を保存
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CSV_FILE))) {
            for (Employee employee : employees) {
                writer.write(employee.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            printLogStackTrace(e, "CSVに社員情報を保存する際に例外が発生しました");
        }
    }

    /**
     * 社員情報のリストを取得する
     * 
     * @return 社員情報リスト
     */
    public List<Employee> getEmployees() {
        return employees; // 社員情報リストを取得
    }
}