import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.List;

/**
 * 社員情報クラス
 */
public class Employee {
    private String id; // 社員ID
    private String name; // 名前
    private LocalDate birthDate; // 生年月日
    private LocalDate joinDate; // 入社日
    private List<String> languages; // 扱える言語
    private String career; // 経歴
    private String trainingHistory; // 研修の受講歴
    private double technicalSkill; // 技術力
    private double learningAttitude; // 受講態度
    private double communicationSkill; // コミュニケーション能力
    private double leadership; // リーダーシップ
    private String remarks; // 備考
    private LocalDateTime savedDate; // 保存日時

    /**
     * コンストラクタ
     * 
     * @param id        社員ID
     * @param name      名前
     * @param birthDate 生年月日
     */
    public Employee(String id, String name, LocalDate birthDate, LocalDate joinDate, List<String> languages,
            String career, String trainingHistory, double technicalSkill, double learningAttitude,
            double communicationSkill, double leadership, String remarks) {
        this.id = id;
        this.name = name;
        this.birthDate = birthDate;
        this.joinDate = joinDate;
        this.languages = languages;
        this.career = career;
        this.trainingHistory = trainingHistory;
        this.technicalSkill = technicalSkill;
        this.learningAttitude = learningAttitude;
        this.communicationSkill = communicationSkill;
        this.leadership = leadership;
        this.remarks = remarks;

        this.savedDate = LocalDateTime.now();
    }

    /**
     * 社員IDを取得する
     * 
     * @return 社員IDを取得する
     */
    public String getId() {
        return id;
    }

    /**
     * 名前を取得する
     * 
     * @return 名前
     */
    public String getName() {
        return name;
    }

    /**
     * 生年月日を取得する
     * 
     * @return 生年月日
     */
    public LocalDate getBirthDate() {
        return birthDate;
    }

    /**
     * 入社日を取得する
     * 
     * @return 入社日
     */
    public LocalDate getJoinDate() {
        return joinDate;
    }

    /**
     * 言語を取得する
     * 
     * @return 言語
     */
    public List<String> getLanguages() {
        return languages;
    }

    /**
     * 保存日時を取得する
     * 
     * @return 保存日時
     */
    public LocalDateTime getSavedDate() {
        return savedDate;
    }

    /**
     * 年齢を取得する
     * 
     * @return 年齢
     */
    public int getAge() {
        return Period.between(birthDate, LocalDate.now()).getYears();
    }

    /**
     * エンジニア歴を取得する
     * 
     * @return エンジニア歴
     */
    public int getEngineerYears() {
        return Period.between(joinDate, LocalDate.now()).getYears();
    }

    public String getCareer() {
        return career;
    }

    public String getTrainingHistory() {
        return trainingHistory;
    }

    public double getTechnicalSkill() {
        return technicalSkill;
    }

    public double getLearningAttitude() {
        return learningAttitude;
    }

    public double getCommunicationSkill() {
        return communicationSkill;
    }

    public double getLeadership() {
        return leadership;
    }

    public String getRemarks() {
        return remarks;
    }

    /**
     * 名前を更新する
     * 
     * @return 名前
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 生年月日を更新する
     * 
     * @return 生年月日
     */
    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    /**
     * 入社日を更新する
     * 
     * @return 入社日
     */
    public void setJoinDate(LocalDate joinDate) {
        this.joinDate = joinDate;
    }

    /**
     * 言語を更新する
     * 
     * @return 言語
     */
    public void setLanguages(List<String> languages) {
        this.languages = languages;
    }

    public void setCareer(String career) {
        this.career = career;
    }

    public void setTrainingHistory(String trainingHistory) {
        this.trainingHistory = trainingHistory;
    }

    public void setTechnicalSkill(double technicalSkill) {
        this.technicalSkill = technicalSkill;
    }

    public void setLearningAttitude(double learningAttitude) {
        this.learningAttitude = learningAttitude;
    }

    public void setCommunicationSkill(double communicationSkill) {
        this.communicationSkill = communicationSkill;
    }

    public void setLeadership(double leadership) {
        this.leadership = leadership;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return id + "," +
                name + "," +
                birthDate + "," +
                joinDate + "," +
                String.join("/", languages); // CSV形式での出力用フォーマット
    }
}