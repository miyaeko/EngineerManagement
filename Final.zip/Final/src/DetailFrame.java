import javax.swing.*;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.util.Arrays;

public class DetailFrame extends JFrame {
        private EmployeeManager manager;
        private Employee employee;
        private JTextField nameField;
        private JTextField birthField;
        private JTextField joinField;
        private JTextField langField;
        private JTextArea careerArea;
        private JTextArea trainingArea;
        private JComboBox<Double> technicalBox;
        private JComboBox<Double> attitudeBox;
        private JComboBox<Double> communicationBox;
        private JComboBox<Double> leadershipBox;
        private JTextArea remarksArea;

        // コンストラクタ
        public DetailFrame(EmployeeManager manager, Employee employee) {
                this.manager = manager;
                this.employee = employee;
                setupUI();
        }

        // UI

        private void setupUI() {
                setTitle("詳細情報");
                setSize(600, 800);
                setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel formPanel = new JPanel();

        GridBagLayout layout =
                new GridBagLayout();

        GridBagConstraints gbc =
                new GridBagConstraints();
                formPanel.setLayout(layout);

                gbc.insets = new Insets(5, 5, 5, 5);
                gbc.fill = GridBagConstraints.HORIZONTAL;

                // 社員IDラベル
                gbc.gridx = 0;
                gbc.gridy = 0;
                gbc.weightx = 0;

                formPanel.add(
                        new JLabel("社員ID"),
                        gbc);

                // 社員ID入力欄
                JTextField idField =
                        new JTextField(employee.getId());

                idField.setEditable(false);

                gbc.gridx = 1;
                gbc.gridy = 0;
                gbc.weightx = 1.0;

                formPanel.add(idField, gbc);

                // 氏名
                gbc.gridx = 0;
                gbc.gridy = 1;
                gbc.weightx = 0;

                formPanel.add(
                        new JLabel("氏名"),
                        gbc);

                nameField =
                        new JTextField(
                                employee.getName());

                gbc.gridx = 1;
                gbc.gridy = 1;
                gbc.weightx = 1.0;

                formPanel.add(
                        nameField,
                        gbc);

                // 生年月日
                gbc.gridx = 0;
                gbc.gridy = 2;
                gbc.weightx = 0;

                formPanel.add(
                        new JLabel("生年月日"),
                        gbc);

                birthField =
                        new JTextField(
                                employee.getBirthDate().toString());

                gbc.gridx = 1;
                gbc.gridy = 2;
                gbc.weightx = 1.0;

                formPanel.add(
                        birthField,
                        gbc);


                // 入社日
                gbc.gridx = 0;
                gbc.gridy = 3;
                gbc.weightx = 0;

                formPanel.add(
                        new JLabel("入社日"),
                        gbc);

                joinField =
                        new JTextField(
                                employee.getJoinDate().toString());

                gbc.gridx = 1;
                gbc.gridy = 3;
                gbc.weightx = 1.0;

                formPanel.add(
                        joinField,
                        gbc);

                // 扱える言語
                gbc.gridx = 0;
                gbc.gridy = 4;
                gbc.weightx = 0;

                formPanel.add(
                        new JLabel("扱える言語"),
                        gbc);

                langField =
                        new JTextField(
                                String.join(",",
                                        employee.getLanguages()));

                gbc.gridx = 1;
                gbc.gridy = 4;
                gbc.weightx = 1.0;

                formPanel.add(
                        langField,
                        gbc);

                // 経歴
                gbc.gridx = 0;
                gbc.gridy = 5;
                gbc.weightx = 0;

                formPanel.add(
                        new JLabel("経歴"),
                        gbc);

                careerArea =
                        new JTextArea(
                                employee.getCareer());

                careerArea.setRows(4);
                careerArea.setLineWrap(true);

                gbc.gridx = 1;
                gbc.gridy = 5;
                gbc.weightx = 1.0;

                formPanel.add(
                        new JScrollPane(careerArea),
                        gbc);

                // 研修受講歴
                gbc.gridx = 0;
                gbc.gridy = 6;
                gbc.weightx = 0;

                formPanel.add(
                        new JLabel("研修受講歴"),
                        gbc);

                trainingArea =
                        new JTextArea(
                                employee.getTrainingHistory());

                trainingArea.setRows(4);
                trainingArea.setLineWrap(true);

                gbc.gridx = 1;
                gbc.gridy = 6;
                gbc.weightx = 1.0;

                formPanel.add(
                        new JScrollPane(trainingArea),
                        gbc);

                Double[] scores = {
                        1.0, 1.5,
                        2.0, 2.5,
                        3.0, 3.5,
                        4.0, 4.5,
                        5.0
                };

                // 技術力
                gbc.gridx = 0;
                gbc.gridy = 7;

                formPanel.add(
                        new JLabel("技術力"),
                        gbc);

                technicalBox =
                        new JComboBox<>(scores);

                technicalBox.setSelectedItem(
                        employee.getTechnicalSkill());

                gbc.gridx = 1;
                gbc.gridy = 7;

                formPanel.add(
                        technicalBox,
                        gbc);

                // 受講態度
                gbc.gridx = 0;
                gbc.gridy = 8;

                formPanel.add(
                        new JLabel("受講態度"),
                        gbc);

                attitudeBox =
                        new JComboBox<>(scores);

                attitudeBox.setSelectedItem(
                        employee.getLearningAttitude());

                gbc.gridx = 1;
                gbc.gridy = 8;

                formPanel.add(
                        attitudeBox,
                        gbc);

                // コミュニケーション能力
                gbc.gridx = 0;
                gbc.gridy = 9;

                formPanel.add(
                        new JLabel("コミュニケーション能力"),
                        gbc);

                communicationBox =
                        new JComboBox<>(scores);

                communicationBox.setSelectedItem(
                        employee.getCommunicationSkill());

                gbc.gridx = 1;
                gbc.gridy = 9;

                formPanel.add(
                        communicationBox,
                        gbc);

                // リーダーシップ
                gbc.gridx = 0;
                gbc.gridy = 10;

                formPanel.add(
                        new JLabel("リーダーシップ"),
                        gbc);

                leadershipBox =
                        new JComboBox<>(scores);

                leadershipBox.setSelectedItem(
                        employee.getLeadership());

                gbc.gridx = 1;
                gbc.gridy = 10;

                formPanel.add(
                        leadershipBox,
                        gbc);

                // 備考
                gbc.gridx = 0;
                gbc.gridy = 11;

                formPanel.add(
                        new JLabel("備考"),
                        gbc);

                remarksArea =
                        new JTextArea(
                                employee.getRemarks());

                remarksArea.setRows(4);
                remarksArea.setLineWrap(true);

                gbc.gridx = 1;
                gbc.gridy = 11;

                formPanel.add(
                        new JScrollPane(remarksArea),
                        gbc);

                // 保存日時
                gbc.gridx = 0;
                gbc.gridy = 12;

                formPanel.add(
                        new JLabel("保存日時"),
                        gbc);

                DateTimeFormatter formatter =
                        DateTimeFormatter.ofPattern(
                                "yyyy/MM/dd HH:mm:ss");

                JLabel saveDateLabel =
                        new JLabel(
                                employee.getSavedDate()
                                        .format(formatter));

                gbc.gridx = 1;
                gbc.gridy = 12;

                formPanel.add(
                        saveDateLabel,
                        gbc);

                // 更新ボタン
                JButton updateButton =
                        new JButton("更新");

                updateButton.addActionListener(
                        e -> updateEmployee());

                gbc.gridx = 1;
                gbc.gridy = 13;

                formPanel.add(
                        updateButton,
                        gbc);

                // 画面に追加
                add(new JScrollPane(formPanel));

                setVisible(true);
        }

        private void updateEmployee() {
                employee.setName(nameField.getText());

                employee.setBirthDate(LocalDate.parse(birthField.getText()));

                employee.setJoinDate(LocalDate.parse(joinField.getText()));

                employee.setLanguages(Arrays.asList(langField.getText().split(",")));

                employee.setCareer(careerArea.getText());

                employee.setTrainingHistory(trainingArea.getText());

                employee.setTechnicalSkill((Double) technicalBox.getSelectedItem());

                employee.setLearningAttitude((Double) attitudeBox.getSelectedItem());

                employee.setCommunicationSkill((Double) communicationBox.getSelectedItem());

                employee.setLeadership((Double) leadershipBox.getSelectedItem());

                employee.setRemarks(remarksArea.getText());
                // csv保存
                manager.saveEmployees();

                JOptionPane.showMessageDialog(this, "更新しました");
        }
}