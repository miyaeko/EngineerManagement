import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/**
 * 社員情報管理アプリのGUI表示するクラス
 */
public class EmployeeView extends JFrame {
        private EmployeeManager manager; // 社員情報の管理クラス
        private JTable table;
        private DefaultTableModel model;
        private TableRowSorter<DefaultTableModel> sorter;

        /**
         * コンストラクタ
         * 
         * @param manager 社員情報管理クラスのインスタンス
         */
        public EmployeeView(EmployeeManager manager) {
                this.manager = manager;
                setupUI(); // UIの設定
        }

        /**
         * UIを設定する.
         * 内部でUIに表示する文字やボタンを設定している
         */
        private void setupUI() {

                setTitle("社員名簿管理");
                setSize(800, 600);
                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                // カラム名
                String[] columns = {
                                "社員ID",
                                "氏名",
                                "年齢",
                                "エンジニア歴",
                                "扱える言語"
                };

                // テーブルモデル
                model = new DefaultTableModel(columns, 0);
                // JTable作成
                table = new JTable(model);
                // ソート機能
                sorter = new TableRowSorter<>(model);
                table.setRowSorter(sorter);
                // 初期表示
                refreshEmployeeList();
                // 追加ボタン
                JButton addButton = new JButton("社員を追加");
                addButton.addActionListener(
                                e -> addEmployee());
                // 削除ボタン
                JButton removeButton = new JButton("選択した社員を削除");
                removeButton.addActionListener(
                                e -> removeEmployee());
                // 詳細ボタン
                JButton detailButton = new JButton("詳細");
                detailButton.addActionListener(e -> {
                        int row = table.getSelectedRow();
                        if (row == -1) {
                                JOptionPane.showMessageDialog(
                                                this,
                                                "社員を選択してください");
                                return;
                        }

                        int modelRow = table.convertRowIndexToModel(row);
                        Employee emp = manager.getEmployees()
                                        .get(modelRow);
                        new DetailFrame(manager, emp);
                });

                // 検索欄
                JTextField searchField = new JTextField(15);
                // 検索ボタン
                JButton searchButton = new JButton("検索");
                searchButton.addActionListener(e -> {
                        String keyword = searchField.getText();
                        sorter.setRowFilter(RowFilter.regexFilter(keyword));
                        addButton.setEnabled(false);
                        removeButton.setEnabled(false);
                        detailButton.setEnabled(false);
                });

                // ×ボタン
                JButton clearButton = new JButton("×");

                clearButton.addActionListener(e -> {
                        searchField.setText("");
                        sorter.setRowFilter(null);

                        addButton.setEnabled(true);
                        removeButton.setEnabled(true);
                        detailButton.setEnabled(true);
                });

                // ボタンパネル
                JPanel buttonPanel = new JPanel();
                buttonPanel.add(addButton);
                buttonPanel.add(removeButton);
                buttonPanel.add(detailButton);
                JPanel searchPanel = new JPanel();
                searchPanel.add(new JLabel("検索"));
                searchPanel.add(searchField);
                searchPanel.add(searchButton);
                searchPanel.add(clearButton);
                add(new JScrollPane(table),
                                BorderLayout.CENTER);
                add(buttonPanel,
                                BorderLayout.SOUTH);
                add(searchPanel, BorderLayout.NORTH);
        }

        /**
         * 社員情報を追加する.
         * ボタン押下された時の処理
         */
        private void addEmployee() {
                String id = JOptionPane.showInputDialog("社員IDを入力してください:");
                String name = JOptionPane.showInputDialog("名前を入力してください:");
                LocalDate birthDate = LocalDate.parse(JOptionPane.showInputDialog("生年月日を入力してください (YYYY-MM-DD):"));
                LocalDate joinDate = LocalDate.parse(JOptionPane.showInputDialog("入社日を入力してください (YYYY-MM-DD):"));
                String langText = JOptionPane.showInputDialog("扱える言語（,区切り）：");
                String career = JOptionPane.showInputDialog("経歴:");
                String trainingHistory = JOptionPane.showInputDialog("研修受講歴:");
                double technicalSkill = Double.parseDouble(
                                JOptionPane.showInputDialog(
                                                "技術力(1～5):"));
                double learningAttitude = Double.parseDouble(
                                JOptionPane.showInputDialog(
                                                "受講態度(1～5):"));
                double communicationSkill = Double.parseDouble(
                                JOptionPane.showInputDialog(
                                                "コミュニケーション能力(1～5):"));
                double leadership = Double.parseDouble(
                                JOptionPane.showInputDialog(
                                                "リーダーシップ(1～5):"));
                String remarks = JOptionPane.showInputDialog("備考:");
                Employee emp = new Employee(
                                id,
                                name,
                                birthDate,
                                joinDate,
                                java.util.Arrays.asList(
                                                langText.split(",")),
                                career,
                                trainingHistory,
                                technicalSkill,
                                learningAttitude,
                                communicationSkill,
                                leadership,
                                remarks);
                manager.addEmployee(emp);
                refreshEmployeeList();
        }

        /**
         * 社員情報を削除する.
         * ボタン押下された時の処理
         */
        private void removeEmployee() {
                int[] rows = table.getSelectedRows();
                for (int i = rows.length - 1; i >= 0; i--) {
                        int modelRow = table.convertRowIndexToModel(rows[i]);
                        Employee emp = manager.getEmployees().get(modelRow);
                        manager.removeEmployee(emp);
                }
                refreshEmployeeList();
        }

        /**
         * 社員情報リストをリフレッシュする
         */
        private void refreshEmployeeList() {
                model.setRowCount(0); // リストをクリアしてから再設定
                for (Employee emp : manager.getEmployees()) {
                        model.addRow(new Object[] {
                                        emp.getId(),
                                        emp.getName(),
                                        emp.getAge(),
                                        emp.getEngineerYears(),
                                        String.join(",", emp.getLanguages())
                        });
                }
        }
}